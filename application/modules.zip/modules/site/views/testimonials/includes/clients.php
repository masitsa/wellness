 <div class="cl-wrap icl-wrap">
     <div class="container">

     <div class="row">
     
         <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 pull-left client-logo-flex wow flipInX" data-wow-delay="0.5s" data-wow-offset="100">
         
         <ul id="testi-client-logos" class="icl-carousel">
            <li><a href="testimonials.html#"><img alt="" src="images/nlogo1.png" class="img-responsive client-logo-img"/></a></li>
            <li><a href="testimonials.html#"><img alt="" src="images/nlogo2.png" class="img-responsive client-logo-img"/></a></li>
            <li><a href="testimonials.html#"><img alt="" src="images/nlogo3.png" class="img-responsive client-logo-img"/></a></li>
            <li><a href="testimonials.html#"><img alt="" src="images/nlogo4.png" class="img-responsive client-logo-img"/></a></li>
            <li><a href="testimonials.html#"><img alt="" src="images/nlogo5.png" class="img-responsive client-logo-img"/></a></li>
            <li><a href="testimonials.html#"><img alt="" src="images/nlogo6.png" class="img-responsive client-logo-img"/></a></li>
        </ul>  
         
         </div>

         </div>
         
     </div>

 </div>
