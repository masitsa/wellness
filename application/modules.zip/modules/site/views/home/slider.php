
      <div class="container full-width-container ihome-banner">
                    <div class="banner col-sm-12 col-xs-12 col-md-12">
                        <ul>
                <!-- THE BOXSLIDE EFFECT EXAMPLES  WITH LINK ON THE MAIN SLIDE EXAMPLE -->

                  
                 
                        <li data-transition="papercut" data-slotamount="7">
                         
                              <!-- MAIN IMAGE -->
                              <img src="<?php echo base_url().'assets/'?>images/new-slider/s1-bg.jpg"  alt="slidebg1"  data-bgfit="cover" data-bgposition="left top" data-bgrepeat="no-repeat">
                              <!-- LAYERS -->
                              <!-- LAYER NR. 1 -->
                              <div class="tp-caption lfb skewtoright imed-sl1"
                                  data-x="left"
                                  data-y="bottom"
                                  data-hoffset="0"
                                  data-speed="1000"
                                  data-start="1000"
                                  data-easing="Power4.easeOut"
                                  data-endspeed="400"
                                  data-endeasing="Power1.easeIn"
                                  >
                                  <img src="<?php echo base_url().'assets/'?>images/new-slider/s1-img4.png" alt="" class="img-responsive">
                              </div>

                              <!-- LAYER NR. 2 -->
                             <!--  <div class="tp-caption lft skewtoright imed-sl1"
                                  data-x="left"
                                  data-y="85"
                                  data-hoffset="83"
                                  data-speed="1200"
                                  data-start="1300"
                                  data-easing="Power4.easeOut"
                                  data-endspeed="400"
                                  data-endeasing="Power1.easeIn"
                                  ><img src="<?php echo base_url().'assets/'?>images/new-slider/s1-img3.png" alt="" class="img-responsive">
                              </div> -->

                              <!-- LAYER NR. 3 -->
                              <!-- <div class="tp-caption lft skewtoright imed-sl1"
                                  data-x="left"
                                  data-y="74"
                                  data-hoffset="45"
                                  data-speed="1400"
                                  data-start="1600"
                                  data-easing="Power4.easeOut"
                                  data-endspeed="400"
                                  data-endeasing="Power1.easeIn"
                                  ><img src="<?php echo base_url().'assets/'?>images/new-slider/s1-img2.png" alt="" class="img-responsive">
                              </div> -->

                              <!-- LAYER NR. 4 -->
                             <!--  <div class="tp-caption lft skewtoright imed-sl1"
                                  data-x="left"
                                  data-y="45"
                                  data-hoffset="61"
                                  data-speed="1600"
                                  data-start="1900"
                                  data-easing="Power4.easeOut"
                                  data-endspeed="400"
                                  data-endeasing="Power1.easeIn"
                                  ><img src="<?php echo base_url().'assets/'?>images/new-slider/s1-img1.png" alt="" class="img-responsive">
                              </div> -->
                              
                              <!-- LAYER NR. 5 -->
                              <div class="tp-caption bluebg-t1 sfr skewtoright imed-sl1"
                                  data-x="right"
                                  data-y="115"
                                  data-hoffset="-60"
                                  data-speed="1000"
                                  data-start="2400"
                                  data-easing="Back.easeOut"
                                  data-endspeed="400"
                                  data-endeasing="Power1.easeIn"
                                  >Absolute Wellness Center Offers:
                              </div>


                              <!-- LAYER NR. 6 -->
                              <!-- <div class="tp-caption bluebg-t2 sfr skewtoright imed-sl1"
                                  data-x="right"
                                  data-y="180"
                                  data-hoffset="-50"
                                  data-speed="1000"
                                  data-start="2900"
                                  data-easing="Back.easeOut"
                                  data-endspeed="400"
                                  data-endeasing="Power1.easeIn"
                                  > Offer:
                              </div> -->


                              <!-- LAYER NR. 7 -->
                              <div class="tp-caption bluebg-t2 sfr skewtoright imed-sl1"
                                  data-x="right"
                                  data-y="180"
                                  data-hoffset="-60"
                                  data-speed="1000"
                                  data-start="2900"
                                  data-easing="Back.easeOut"
                                  data-endspeed="400"
                                  data-endeasing="Power1.easeIn"
                                  > Nutrition and Diet Consultation.</div>

                                <div class="tp-caption bluebg-t2 sfr skewtoright imed-sl1"
                                  data-x="right"
                                  data-y="240"
                                  data-hoffset="-60"
                                  data-speed="1000"
                                  data-start="3510"
                                  data-easing="Back.easeOut"
                                  data-endspeed="400"
                                  data-endeasing="Power1.easeIn"
                                  > Corporate Wellness Program.</div>

                                <div class="tp-caption bluebg-t2 sfr skewtoright imed-sl1"
                                  data-x="right"
                                  data-y="300"
                                  data-hoffset="-60"
                                  data-speed="1000"
                                  data-start="4100"
                                  data-easing="Back.easeOut"
                                  data-endspeed="400"
                                  data-endeasing="Power1.easeIn"
                                  > Maternal Health Care.</div>


                              <!-- LAYER NR. 8 -->
                            
                              
                              
                        
                       </li> 


                       <li data-transition="papercut" data-slotamount="7">
                         
                              <!-- MAIN IMAGE -->
                              <img src="<?php echo base_url().'assets/'?>images/new-slider/s2-bg.jpg"  alt="slidebg1"  data-bgfit="cover" data-bgposition="left top" data-bgrepeat="no-repeat">
                              <!-- LAYERS -->
                              <!-- LAYER NR. 1 -->
                              <div class="tp-caption lfb stl imed-sl1"
                                  data-x="left"
                                  data-y="bottom"
                                  data-hoffset="-50"
                                  data-speed="1000"
                                  data-start="1000"
                                  data-easing="Power4.easeOut"
                                  data-endspeed="400"
                                  data-endeasing="Power1.easeIn"
                                  ><img src="<?php echo base_url().'assets/'?>images/new-slider/s2-img1.png" alt="" class="img-responsive">
                              </div>

                              

                              
                              
                              <!-- LAYER NR. 6 -->
                              <div class="tp-caption whitebg-t1 sfr skewtoright imed-sl1"
                                  data-x="right"
                                  data-y="115"
                                  data-hoffset="-60"
                                  data-speed="1500"
                                  data-start="1600"
                                  data-easing="Back.easeOut"
                                  data-endspeed="400"
                                  data-endeasing="Power1.easeIn"
                                  >We change lives of people by:
                              </div>


                              <!-- LAYER NR. 7 -->
                              <div class="tp-caption whitebg-t2 sfr skewtoright imed-sl1"
                                  data-x="right"
                                  data-y="200"
                                  data-hoffset="-10"
                                  data-speed="1500"
                                  data-start="2100"
                                  data-easing="Back.easeOut"
                                  data-endspeed="400"
                                  data-endeasing="Power1.easeIn"
                                  >Developing practical and realistic goals <br> consitent to your needs
                              </div>


                        
                       </li>


                       <li data-transition="papercut" data-slotamount="7">
                         
                              <!-- MAIN IMAGE -->
                              <img src="<?php echo base_url().'assets/'?>images/new-slider/s3-bg.jpg"  alt="slidebg1"  data-bgfit="cover" data-bgposition="left top" data-bgrepeat="no-repeat">
                              <!-- LAYERS -->
                              <!-- LAYER NR. 1 -->
                              <div class="tp-caption sfb skewtoright imed-sl1 rs-parallaxlevel-1"
                                  data-x="left"
                                  data-y="30"
                                  data-hoffset="-20"
                                  data-speed="1000"
                                  data-start="1000"
                                  data-easing="Power4.easeOut"
                                  data-endspeed="400"
                                  data-endeasing="Power1.easeIn"
                                  ><img src="<?php echo base_url().'assets/'?>images/new-slider/s3-img1.png" alt="" class="img-responsive">
                              </div>

                             

                              
                              <!-- LAYER NR. 5 -->
                              <div class="tp-caption bluebg-t1 sfr skewtoright imed-sl1"
                                  data-x="right"
                                  data-y="115"
                                  data-hoffset="-60"
                                  data-speed="1000"
                                  data-start="1500"
                                  data-easing="Back.easeOut"
                                  data-endspeed="400"
                                  data-endeasing="Power1.easeIn"
                                  >Visit us now !
                              </div>


                              <!-- LAYER NR. 6 -->
                              <div class="tp-caption bluebg-t2 sfr skewtoright imed-sl1"
                                  data-x="right"
                                  data-y="222"
                                  data-hoffset="-10"
                                  data-speed="1000"
                                  data-start="2000"
                                  data-easing="Back.easeOut"
                                  data-endspeed="400"
                                  data-endeasing="Power1.easeIn"
                                  >To experince a change in your life
                              </div>


                              <!-- LAYER NR. 7 -->
                            <!--   <div class="tp-caption bluebg-t3 sfr skewtoright imed-sl1"
                                  data-x="right"
                                  data-y="220"
                                  data-hoffset="-60"
                                  data-speed="1000"
                                  data-start="2500"
                                  data-easing="Back.easeOut"
                                  data-endspeed="400"
                                  data-endeasing="Power1.easeIn"
                                  >experince a change in your life.</div> -->


                              <!-- LAYER NR. 8 -->
                              <div class="tp-caption s1-but customin skewtoright imed-sl1"
                                  data-x="center"
                                  data-y="365"
                                  data-hoffset="205"
                                  data-speed="1000"
                                  data-customin="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
                                  data-start="3900"
                                  data-easing="Back.easeOut"
                                  data-endspeed="400"
                                  data-endeasing="Power1.easeIn"
                                  ><a href="index.html#">Purchase Now</a></div>
                              
                              
                              
                        
                       </li>  


                        <li data-transition="papercut" data-slotamount="7">
                         
                              <!-- MAIN IMAGE -->
                              <img src="<?php echo base_url().'assets/'?>images/new-slider/s3-bg.jpg"  alt="slidebg1"  data-bgfit="cover" data-bgposition="left top" data-bgrepeat="no-repeat">
                              <!-- LAYERS -->
                              <!-- LAYER NR. 1 -->
                              <div class="tp-caption lfb skewtoright imed-sl1"
                                  data-x="left"
                                  data-y="bottom"
                                  data-hoffset="-30"
                                  data-speed="1000"
                                  data-start="1000"
                                  data-easing="Power4.easeOut"
                                  data-endspeed="400"
                                  data-endeasing="Power1.easeIn"
                                  ><img src="<?php echo base_url().'assets/'?>images/new-slider/s4-img9.png" alt="" class="img-responsive">
                              </div>

                              <!-- LAYER NR. 2 -->
                              <div class="tp-caption lfb skewtoright imed-sl1"
                                  data-x="left"
                                  data-y="113"
                                  data-hoffset="274"
                                  data-speed="1500"
                                  data-start="1400"
                                  data-easing="Power4.easeOut"
                                  data-endspeed="400"
                                  data-endeasing="Power1.easeIn"
                                  ><img src="<?php echo base_url().'assets/'?>images/new-slider/s4-img8.png" alt="" class="img-responsive">
                              </div>

                              <!-- LAYER NR. 3 -->
                              <div class="tp-caption lfb skewtoright imed-sl1"
                                  data-x="left"
                                  data-y="103"
                                  data-hoffset="192"
                                  data-speed="1400"
                                  data-start="1800"
                                  data-easing="Power4.easeOut"
                                  data-endspeed="400"
                                  data-endeasing="Power1.easeIn"
                                  ><img src="<?php echo base_url().'assets/'?>images/new-slider/s4-img7.png" alt="" class="img-responsive">
                              </div>

                              <!-- LAYER NR. 3 -->
                              <div class="tp-caption lfb skewtoright imed-sl1"
                                  data-x="left"
                                  data-y="111"
                                  data-hoffset="192"
                                  data-speed="1400"
                                  data-start="2200"
                                  data-easing="Power4.easeOut"
                                  data-endspeed="400"
                                  data-endeasing="Power1.easeIn"
                                  ><img src="<?php echo base_url().'assets/'?>images/new-slider/s4-img6.png" alt="" class="img-responsive">
                              </div>

                              <!-- LAYER NR. 3 -->
                              <div class="tp-caption lfb skewtoright imed-sl1"
                                  data-x="left"
                                  data-y="94"
                                  data-hoffset="6"
                                  data-speed="1400"
                                  data-start="2600"
                                  data-easing="Power4.easeOut"
                                  data-endspeed="400"
                                  data-endeasing="Power1.easeIn"
                                  ><img src="<?php echo base_url().'assets/'?>images/new-slider/s4-img5.png" alt="" class="img-responsive">
                              </div>

                              <!-- LAYER NR. 3 -->
                              <div class="tp-caption lft skewtoright imed-sl1"
                                  data-x="left"
                                  data-y="99"
                                  data-hoffset="273"
                                  data-speed="1400"
                                  data-start="3000"
                                  data-easing="Power4.easeOut"
                                  data-endspeed="400"
                                  data-endeasing="Power1.easeIn"
                                  ><img src="<?php echo base_url().'assets/'?>images/new-slider/s4-img4.png" alt="" class="img-responsive">
                              </div>

                              <!-- LAYER NR. 3 -->
                              <div class="tp-caption lft skewtoright imed-sl1"
                                  data-x="left"
                                  data-y="29"
                                  data-hoffset="-20"
                                  data-speed="1400"
                                  data-start="3400"
                                  data-easing="Power4.easeOut"
                                  data-endspeed="400"
                                  data-endeasing="Power1.easeIn"
                                  ><img src="<?php echo base_url().'assets/'?>images/new-slider/s4-img3.png" alt="" class="img-responsive">
                              </div>

                              <!-- LAYER NR. 3 -->
                              <div class="tp-caption lft skewtoright imed-sl1"
                                  data-x="left"
                                  data-y="73"
                                  data-hoffset="0"
                                  data-speed="1400"
                                  data-start="3800"
                                  data-easing="Power4.easeOut"
                                  data-endspeed="400"
                                  data-endeasing="Power1.easeIn"
                                  ><img src="<?php echo base_url().'assets/'?>images/new-slider/s4-img2.png" alt="" class="img-responsive">
                              </div>

                              <!-- LAYER NR. 3 -->
                              <div class="tp-caption lft skewtoright imed-sl1"
                                  data-x="left"
                                  data-y="89"
                                  data-hoffset="192"
                                  data-speed="1400"
                                  data-start="4200"
                                  data-easing="Power4.easeOut"
                                  data-endspeed="400"
                                  data-endeasing="Power1.easeIn"
                                  ><img src="<?php echo base_url().'assets/'?>images/new-slider/s4-img1.png" alt="" class="img-responsive">
                              </div>

                              
                              <!-- LAYER NR. 5 -->
                              <div class="tp-caption bluebg-t1 sfr skewtoright imed-sl1"
                                  data-x="right"
                                  data-y="115"
                                  data-hoffset="-40"
                                  data-speed="1000"
                                  data-start="4800"
                                  data-easing="Back.easeOut"
                                  data-endspeed="400"
                                  data-endeasing="Power1.easeIn"
                                  >Customize each & every<br>page easily !
                              </div>


                              <!-- LAYER NR. 6 -->
                              <div class="tp-caption bluebg-t2 sfr skewtoright imed-sl1"
                                  data-x="right"
                                  data-y="222"
                                  data-hoffset="10"
                                  data-speed="1000"
                                  data-start="5200"
                                  data-easing="Back.easeOut"
                                  data-endspeed="400"
                                  data-endeasing="Power1.easeIn"
                                  >Experience the real life situations
                              </div>


                              <!-- LAYER NR. 7 -->
                              <div class="tp-caption bluebg-t3 sfr skewtoright imed-sl1"
                                  data-x="right"
                                  data-y="280"
                                  data-hoffset="-40"
                                  data-speed="1000"
                                  data-start="5500"
                                  data-easing="Back.easeOut"
                                  data-endspeed="400"
                                  data-endeasing="Power1.easeIn"
                                  >Lorem Ipsum is simply dummy text of the printing and typesetting<br> industry, it has been the industry's standard.</div>


                              <!-- LAYER NR. 8 -->
                              <div class="tp-caption s1-but customin skewtoright imed-sl1"
                                  data-x="center"
                                  data-y="365"
                                  data-hoffset="225"
                                  data-speed="1000"
                                  data-customin="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
                                  data-start="5700"
                                  data-easing="Back.easeOut"
                                  data-endspeed="400"
                                  data-endeasing="Power1.easeIn"
                                  ><a href="index.html#">Purchase Now</a></div>
                              
                              
                              
                        
                       </li>
                      
                      </ul>
                  </div>
              </div>