 <div class="parallax-out wpb_row vc_row-fluid ihome-parallax">    
              
                
                    <div id="second" class="upb_row_bg vcpb-hz-jquery" data-upb_br_animation="" data-parallax_sense="30" data-bg-override="ex-full">
                    
                          <div class="container">
                            <div class="row">
                          
                          <div class="bg col-lg-4 col-sm-4 col-md-5 col-xs-12 notViewed wow fadeInUp" data-wow-delay="1.5s" data-wow-offset="200"></div>
                          
                            <div class="float-right col-lg-7 col-sm-7 col-md-7 col-xs-12">
                                
                                <div class="iconlist-wrap">
                                <div class="subtitle notViewed wow fadeInRight" data-wow-delay="0.5s" data-wow-offset="20">Why <span class="iconlist-mid-title">Choose</span> Us</div>
                                <ul>
                                    <li class="notViewed wow fadeInDown" data-wow-delay="0.5s" data-wow-offset="50">
                                    <i class="icon-hospital2 icon-list-icons"></i>
                                    <div class="iconlist-content">
                                        
                                        <div class="iconlist-title">Promote healthy lifestyle by sharing information.</div>
                                        <p class="iconlist-text">Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium
        doloremque laudantium, totam rem aperiam. </p>
                                    </div>
                                    
                                    </li>
                                    
                                    <li class="notViewed wow fadeInDown" data-wow-delay="0.5s" data-wow-offset="60">
                                    <i class="fa fa-user-md icon-list-icons"></i>
                                    <div class="iconlist-content">
                                        
                                        <div class="iconlist-title">Empower the community to change harmful habits.</div>
                                        <p class="iconlist-text">Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium
        doloremque laudantium, totam rem aperiam. </p>
                                    </div>
                                   
                                    </li>
                                    
                                    <li class="notViewed wow fadeInDown" data-wow-delay="0.5s" data-wow-offset="70">
                                    <i class="fa fa-ambulance icon-list-icons"></i>
                                    <div class="iconlist-content">
                                        
                                        <div class="iconlist-title">Emergency Departments</div>
                                        <p class="iconlist-text">Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium
        doloremque laudantium, totam rem aperiam. </p>
                                    </div>
                                    </li>
                                </ul>
                                </div>
                                
                                
                            </div>
                        </div> <!--.story-->
                        </div>
                    </div> <!--#second-->
                    
                </div>