<div class="container"> 
	<div class="call-action-container">
   
        <div class="col-xs-12 col-md-12 col-sm-12 no-pad call-action-title wow pulse animated" data-wow-delay="0.5s" data-wow-offset="150">
         	<div id="call-action-title">Suitable For Any Medical & Health Related Projects</div>
            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
            
        
            <section class="color-4 purchase-strip-blue ipurchase-text-center">
                    <p class="ipurchase-paragraph">
                        <button class="btn btn-4 btn-4a notViewed purshase-theme-btn">Purchase Theme</button>
                    </p>
            </section>
            
       
        </div>
        
    </div>
 </div>