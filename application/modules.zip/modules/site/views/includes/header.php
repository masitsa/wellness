 <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
        
        <title><?php echo $title;?></title>

        <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700,300' rel='stylesheet' type='text/css'>
        <link href='http://fonts.googleapis.com/css?family=Noto+Sans:400,700,400italic' rel='stylesheet' type='text/css'>
        
        <link href="<?php echo base_url().'assets/themes/iMedica/'?>css/jquery-ui-1.10.3.custom.css" rel="stylesheet" />
        <link href="<?php echo base_url().'assets/themes/iMedica/'?>css/animate.css" rel="stylesheet" />
        <link href="<?php echo base_url().'assets/themes/iMedica/'?>css/font-awesome.min.css" rel="stylesheet" />
        <link rel="stylesheet" type="text/css" href="<?php echo base_url().'assets/themes/iMedica/'?>css/blue.css" id="style-switch" />
        <!-- REVOLUTION BANNER CSS SETTINGS -->
        <link rel="stylesheet" type="text/css" href="r<?php echo base_url().'assets/themes/iMedica/'?>s-plugin/css/settings.min.css" media="screen" />
        <!--[if IE 9]>
            <link rel="stylesheet" type="text/css" href="css/ie9.css" />
        <![endif]-->    
        <link rel="icon" type="image/png" href="<?php echo base_url().'assets/themes/iMedica/'?>images/fevicon.png">

        <link rel="stylesheet" type="text/css" href="<?php echo base_url().'assets/themes/iMedica/'?>css/slides.css" />
        <link rel="stylesheet" type="text/css" href="<?php echo base_url().'assets/themes/iMedica/'?>css/inline.min.css" />
        <link rel="stylesheet" type="text/css" href="<?php echo base_url().'assets/themes/iMedica/'?>rs-plugin/css/settings.css" />
        <link rel="stylesheet" type="text/css" href="<?php echo base_url().'assets/themes/iMedica/'?>rs-plugin/css/settings.min.css" />
        
        

    </head>